/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * An AST node location interface.
 *
 * @alias Blockly.IASTNodeLocation
 */
export interface IASTNodeLocation {
}
//# sourceMappingURL=i_ast_node_location.d.ts.map