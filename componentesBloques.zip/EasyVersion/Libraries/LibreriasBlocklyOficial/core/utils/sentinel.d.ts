/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * A type used to create flag values.
 *
 * @alias Blockly.utils.Sentinel
 */
export declare class Sentinel {
}
//# sourceMappingURL=sentinel.d.ts.map