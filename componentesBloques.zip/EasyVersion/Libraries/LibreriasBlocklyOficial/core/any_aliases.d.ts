type any = any;
//# sourceMappingURL=any_aliases.d.ts.map