declare const Blockly: any;
declare const ContextMenu: any;
declare const Events: any;
declare const Msg: any;
declare const Tooltip: any;
declare const WidgetDiv: any;
declare const colour: any;
declare const common: any;
declare const deprecation: any;
declare const dialog: any;
declare const eventUtils: any;
//# sourceMappingURL=main.d.ts.map