/** @file Re-exports of Blockly.thrasos.* modules. */
import { RenderInfo } from './info.js';
import { Renderer } from './renderer.js';
export { Renderer, RenderInfo };
//# sourceMappingURL=thrasos.d.ts.map