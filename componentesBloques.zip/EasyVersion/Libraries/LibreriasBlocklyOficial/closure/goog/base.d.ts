export {};
//# sourceMappingURL=base.d.ts.map